from flask import Flask, request, render_template
app = Flask(__name__)

@app.route('/')
def my_form():
    return render_template('index.html')
  
@app.route('/pipeline')
def my_pipe():
    clusname = request.args.get('clusname')
    bmetal = request.args.get('bmetal')
    if (bmetal == "Yes"): return render_template('test1.html', clusname=clusname)
    return render_template('test.html', clusname=clusname)  

@app.route('/pipeline1')
def my_pipe1():
    clusname = "Cluster"
    return render_template('test.html',clusname=clusname)  

@app.route('/pipeline2')
def my_pipe2():
    return render_template('test02.html')   

@app.route('/', methods=['POST'])
def my_form_post():
    clusname = request.form['clusname']
    pcc = request.form['pcc']
    wcount = str(request.form['wcount'])
    srovcount = str(request.form['srovcount'])
    tvimzone = request.form['tvimzone']
    vlanid1 = str(request.form['vlanid1'])
    vlanid2 = str(request.form['vlanid2'])
    vlanid3 = str(request.form['vlanid3'])
    vlanid4 = str(request.form['vlanid4'])
    
    htmlout= """
    
    <html>
    <h1> Details entered </h1>
<head>
<style>
table, th, td {
  border: 1px solid black;
}
</style>
</head>
<body>
    <table >
      <tr>
        <td>Cluster name: </td> <td>%s</td>
      </tr>
      <tr>
        <td>Pcc: </td> <td> %s </td> 
    </tr>
    <tr>
    <td>Worker Node Count: </td> <td> %s </td> 
    </tr>
    <tr>
    <td> SROV Node Count: </td> <td> %s </td>     
    </tr>
    <tr>
      <td>Target VIM Zone: </td> <td> %s </td>
    </tr>
    <tr>
      <td>CIDR for VlanID 1001: </td> <td>%s </td> 
    <tr>
        <tr>
      <td>CIDR VlanID 3012: </td> <td>%s </td> 
    <tr>
        <tr>
      <td>CIDR VlanID 2020 </td> <td>%s </td> 
    <tr>
        <tr>
      <td>CIDR VlanID 2339</td> <td>%s </td> 
    <tr>
    
    
    </body>
    </html>
    
    
    """ %(clusname,pcc,wcount,srovcount,tvimzone,vlanid1,vlanid2,vlanid3,vlanid4)
    return htmlout

if __name__ == '__main__':
    app.run(debug=True)